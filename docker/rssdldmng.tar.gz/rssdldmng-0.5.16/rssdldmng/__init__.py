"""Init file for RSS downloader."""
